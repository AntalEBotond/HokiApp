<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Services\AuthService;
use App\Services\ProfileService;

$config = require __DIR__ . '/../../config/config.php';
$auth = new AuthService(new UserRepository(), new TokenRepository(), $config['auth']['token_ttl'] ?? (7*24*3600));

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
if ($authHeader === '' && function_exists('getallheaders')) {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
    }
}
$user = $auth->authenticate($authHeader);
if (!$user) {
    Response::json(['error' => 'Unauthorized'], 401);
}

$profile = new ProfileService(new UserRepository());

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        Response::json(['profile' => $profile->getProfile($user)]);
        break;
    case 'POST':
    case 'PUT':
    case 'PATCH':
        $data = read_json_body();
        $updated = $profile->updateProfile($user, $data);
        Response::json(['profile' => $updated]);
        break;
    default:
        Response::json(['error' => 'Method Not Allowed'], 405);
}
