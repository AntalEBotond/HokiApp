<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Services\AuthService;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::json(['error' => 'Method Not Allowed'], 405);
}

$body = read_json_body();
$username = trim($body['username'] ?? '');
$password = (string)($body['password'] ?? '');
$fullName = isset($body['full_name']) ? trim((string)$body['full_name']) : null;
// Email is not used in this project; ignore any provided email
$email = null;

if ($username === '' || $password === '') {
    Response::json(['error' => 'username and password are required'], 400);
}

try {
    $auth = new AuthService(new UserRepository(), new TokenRepository(), 7*24*3600);
    $user = $auth->register($username, $password, $fullName, $email);
    Response::json(['user' => $user->toPublicArray()]);
} catch (\PDOException $e) {
    // Likely a duplicate username/email, but avoid exposing details
    Response::json(['error' => 'Registration failed'], 400);
}
