<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Services\AuthService;

$config = require __DIR__ . '/../../config/config.php';
$auth = new AuthService(new UserRepository(), new TokenRepository(), $config['auth']['token_ttl'] ?? (7*24*3600));

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
if ($authHeader === '' && function_exists('getallheaders')) {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
    }
}
$user = $auth->authenticate($authHeader);
if (!$user) {
    Response::json(['error' => 'Unauthorized'], 401);
}

$publicDir = realpath(__DIR__ . '/..');
$uploadsDir = $publicDir . DIRECTORY_SEPARATOR . 'uploads';
$avatarsDir = $uploadsDir . DIRECTORY_SEPARATOR . 'avatars';
if (!is_dir($avatarsDir)) {
    @mkdir($avatarsDir, 0777, true);
}

function absolute_url(string $path): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    // If path is already absolute (starts with '/'), keep it; otherwise, prefix with current dir
    if ($path && $path[0] !== '/') $path = '/' . $path;
    return $scheme . '://' . $host . $path;
}

// Determine the public URL base corresponding to $publicDir.
// Example when served via XAMPP under /bot/server/public: '/bot/server/public'
$apiDirUrl = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
$publicUrlBase = rtrim(dirname($apiDirUrl), '/');

function allowed_mime_to_ext(string $mime): ?string {
    static $map = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];
    return $map[$mime] ?? null;
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':
        if (!isset($_FILES['file'])) {
            Response::json(['error' => 'No file uploaded'], 400);
        }
        $file = $_FILES['file'];
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            Response::json(['error' => 'Upload error'], 400);
        }
        if (($file['size'] ?? 0) <= 0 || $file['size'] > 5 * 1024 * 1024) {
            Response::json(['error' => 'Invalid file size'], 400);
        }
        $tmpName = $file['tmp_name'];
        $mime = null;
        if (class_exists('finfo')) {
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($tmpName) ?: null;
        }
        $ext = $mime ? allowed_mime_to_ext($mime) : null;
        if (!$ext) {
            // Fallback to filename extension if finfo not available
            $name = $file['name'] ?? '';
            $extGuess = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $whitelist = ['jpg','jpeg','png','webp','gif'];
            if (in_array($extGuess, $whitelist, true)) {
                $ext = $extGuess === 'jpeg' ? 'jpg' : $extGuess;
            }
        }
        if (!$ext) {
            Response::json(['error' => 'Unsupported file type'], 415);
        }
        $safeName = 'u' . $user->id . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $targetPath = $avatarsDir . DIRECTORY_SEPARATOR . $safeName;
        if (!move_uploaded_file($tmpName, $targetPath)) {
            Response::json(['error' => 'Failed to save file'], 500);
        }
        // Remove old avatar if under uploads/avatars
        $old = $user->avatarUrl ?? null;
        if ($old) {
            $parsed = parse_url($old);
            $oldPath = $parsed['path'] ?? $old;
            $localPath = null;
            if (strpos($oldPath, $publicUrlBase . '/uploads/') === 0) {
                $rel = substr($oldPath, strlen($publicUrlBase));
                $localPath = realpath($publicDir . $rel);
            } elseif (strpos($oldPath, '/uploads/') === 0) {
                $localPath = realpath($publicDir . $oldPath);
            }
            if ($localPath && strpos($localPath, realpath($avatarsDir)) === 0 && file_exists($localPath)) {
                @unlink($localPath);
            }
        }
        // Build URL relative to the public base (handles /bot/server/public in XAMPP)
        $relative = $publicUrlBase . '/uploads/avatars/' . $safeName;
        $user->avatarUrl = absolute_url($relative);

        // Also persist avatar bytes + mime into DB
        $bytes = @file_get_contents($targetPath);
        $mimeForDb = $mime ?: 'application/octet-stream';
        $repo = new UserRepository();
        $repo->updateAvatarData($user->id, $user->avatarUrl, $mimeForDb, $bytes);

        Response::json(['avatar_url' => $user->avatarUrl]);
        break;

    case 'DELETE':
        $old = $user->avatarUrl ?? null;
        if ($old) {
            $parsed = parse_url($old);
            $oldPath = $parsed['path'] ?? $old; // e.g. '/bot/server/public/uploads/avatars/xyz.jpg' or '/uploads/...'
            $localPath = null;
            if (strpos($oldPath, $publicUrlBase . '/uploads/') === 0) {
                // Strip the public URL base
                $rel = substr($oldPath, strlen($publicUrlBase)); // '/uploads/...'
                $localPath = realpath($publicDir . $rel);
            } elseif (strpos($oldPath, '/uploads/') === 0) {
                $localPath = realpath($publicDir . $oldPath);
            }
            if ($localPath && strpos($localPath, realpath($avatarsDir)) === 0 && file_exists($localPath)) {
                @unlink($localPath);
            }
        }
        $user->avatarUrl = null;
        (new UserRepository())->clearAvatarData($user->id);
        Response::json(['ok' => true]);
        break;

    default:
        Response::json(['error' => 'Method Not Allowed'], 405);
}
