<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Repositories\PostRepository;
use App\Services\AuthService;

$config = require __DIR__ . '/../../config/config.php';
$auth = new AuthService(new UserRepository(), new TokenRepository(), $config['auth']['token_ttl'] ?? (7*24*3600));
$repo = new PostRepository();

// Helpers similar to avatar endpoint to build public URLs
$publicDir = realpath(__DIR__ . '/..');
$uploadsDir = $publicDir . DIRECTORY_SEPARATOR . 'uploads';
$postsDir = $uploadsDir . DIRECTORY_SEPARATOR . 'posts';
if (!is_dir($postsDir)) { @mkdir($postsDir, 0777, true); }

$apiDirUrl = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
$publicUrlBase = rtrim(dirname($apiDirUrl), '/');

function absolute_url_posts(string $path): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    if ($path && $path[0] !== '/') $path = '/' . $path;
    return $scheme . '://' . $host . $path;
}

function allowed_mime_to_ext_post(string $mime): ?string {
    static $map = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];
    return $map[$mime] ?? null;
}

// Normalize a stored URL (possibly with old host) to current host
function normalize_public_url(string $url, string $publicUrlBase): string {
    if ($url === '') return $url;
    $p = parse_url($url);
    $path = $p['path'] ?? '';
    if ($path === '') return $url;
    // If path already contains /uploads/, rebuild absolute with current host
    if (strpos($path, '/uploads/') !== false) {
        return absolute_url_posts($path);
    }
    // If input was already relative
    if ($url[0] === '/') {
        return absolute_url_posts($url);
    }
    return $url;
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        $posts = $repo->latest($limit, $offset);
        // Rewrite media URLs to current host so web and devices both work
        foreach ($posts as &$pp) {
            if (isset($pp['image_url']) && is_string($pp['image_url'])) {
                $pp['image_url'] = normalize_public_url($pp['image_url'], $publicUrlBase);
            }
            if (isset($pp['user_avatar']) && is_string($pp['user_avatar'])) {
                $pp['user_avatar'] = normalize_public_url($pp['user_avatar'], $publicUrlBase);
            }
        }
        unset($pp);
        Response::json(['posts' => $posts]);
        break;

    case 'POST':
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if ($authHeader === '' && function_exists('getallheaders')) {
            $headers = getallheaders();
            if (isset($headers['Authorization'])) { $authHeader = $headers['Authorization']; }
        }
        $user = $auth->authenticate($authHeader);
        if (!$user) { Response::json(['error' => 'Unauthorized'], 401); }
        $content = '';
        $imageUrl = null;
        $visibility = 'public';
        $bg = null; $fg = null; $emoji = null;
        if (!empty($_FILES['image'])) {
            // multipart upload
            $content = trim((string)($_POST['content'] ?? ''));
            $visibility = trim((string)($_POST['visibility'] ?? 'public'));
            $bg = isset($_POST['bg_color']) ? trim((string)$_POST['bg_color']) : null;
            $fg = isset($_POST['text_color']) ? trim((string)$_POST['text_color']) : null;
            $emoji = isset($_POST['feeling_emoji']) ? trim((string)$_POST['feeling_emoji']) : null;
            $f = $_FILES['image'];
            if (($f['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) Response::json(['error' => 'Upload error'], 400);
            if (($f['size'] ?? 0) <= 0 || $f['size'] > 8 * 1024 * 1024) Response::json(['error' => 'Invalid file size'], 400);
            $tmp = $f['tmp_name'];
            $mime = null;
            if (class_exists('finfo')) { $fi = new \finfo(FILEINFO_MIME_TYPE); $mime = $fi->file($tmp) ?: null; }
            $ext = $mime ? allowed_mime_to_ext_post($mime) : null;
            if (!$ext) {
                $name = $f['name'] ?? '';
                $guess = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                if (in_array($guess, ['jpg','jpeg','png','webp','gif'], true)) $ext = $guess === 'jpeg' ? 'jpg' : $guess;
            }
            if (!$ext) Response::json(['error' => 'Unsupported file type'], 415);
            $safe = 'p'.$user->id.'_'.time().'_'.bin2hex(random_bytes(4)).'.'.$ext;
            $target = $postsDir . DIRECTORY_SEPARATOR . $safe;
            if (!move_uploaded_file($tmp, $target)) Response::json(['error' => 'Failed to save file'], 500);
            $relative = $publicUrlBase . '/uploads/posts/' . $safe;
            $imageUrl = absolute_url_posts($relative);
        } else {
            // json body
            $body = read_json_body();
            $content = trim((string)($body['content'] ?? ''));
            $visibility = trim((string)($body['visibility'] ?? 'public'));
            $bg = isset($body['bg_color']) ? trim((string)$body['bg_color']) : null;
            $fg = isset($body['text_color']) ? trim((string)$body['text_color']) : null;
            $emoji = isset($body['feeling_emoji']) ? trim((string)$body['feeling_emoji']) : null;
        }
        if ($content === '') { Response::json(['error' => 'content is required'], 400); }
        $post = $repo->create($user->id, $content, $imageUrl, $visibility, $bg, $fg, $emoji);
        Response::json(['post' => $post->toArray()], 201);
        break;

    case 'DELETE':
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if ($authHeader === '' && function_exists('getallheaders')) {
            $headers = getallheaders();
            if (isset($headers['Authorization'])) { $authHeader = $headers['Authorization']; }
        }
        $user = $auth->authenticate($authHeader);
        if (!$user) { Response::json(['error' => 'Unauthorized'], 401); }
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id <= 0) Response::json(['error' => 'id required'], 400);
        // owner check
        $post = $repo->findById($id);
        if (!$post || $post->userId !== $user->id) Response::json(['error' => 'Forbidden'], 403);
        // delete row and file
        $pdo = \App\Core\Database::pdo();
        $stmt = $pdo->prepare('DELETE FROM posts WHERE id = ?');
        $stmt->execute([$id]);
        if ($post->imageUrl) {
            $parsed = parse_url($post->imageUrl);
            $oldPath = $parsed['path'] ?? '';
            if (strpos($oldPath, $publicUrlBase . '/uploads/posts/') === 0) {
                $rel = substr($oldPath, strlen($publicUrlBase));
                $local = realpath($publicDir . $rel);
                if ($local && file_exists($local)) @unlink($local);
            }
        }
        Response::json(['ok' => true]);
        break;

    default:
        // Support PATCH via X-HTTP-Method-Override
        $method = $_SERVER['REQUEST_METHOD'];
        $override = $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? '';
        if (strtoupper($override) === 'PATCH' || $method === 'PATCH' || $method === 'PUT') {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
            if ($authHeader === '' && function_exists('getallheaders')) { $h = getallheaders(); if (isset($h['Authorization'])) $authHeader = $h['Authorization']; }
            $user = $auth->authenticate($authHeader);
            if (!$user) { Response::json(['error' => 'Unauthorized'], 401); }
            $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
            if ($id <= 0) Response::json(['error' => 'id required'], 400);
            $post = $repo->findById($id);
            if (!$post || $post->userId !== $user->id) Response::json(['error' => 'Forbidden'], 403);
            $body = read_json_body();
            $content = trim((string)($body['content'] ?? ''));
            if ($content === '') Response::json(['error' => 'content required'], 400);
            $visibility = trim((string)($body['visibility'] ?? $post->visibility));
            $bg = array_key_exists('bg_color', $body) ? (trim((string)$body['bg_color']) ?: null) : $post->bgColor;
            $fg = array_key_exists('text_color', $body) ? (trim((string)$body['text_color']) ?: null) : $post->textColor;
            $emoji = array_key_exists('feeling_emoji', $body) ? (trim((string)$body['feeling_emoji']) ?: null) : $post->feelingEmoji;
            $pdo = \App\Core\Database::pdo();
            $stmt = $pdo->prepare('UPDATE posts SET content=?, visibility=?, bg_color=?, text_color=?, feeling_emoji=? WHERE id=?');
            $stmt->execute([$content, $visibility, $bg, $fg, $emoji, $id]);
            $post = $repo->findById($id);
            Response::json(['post' => $post->toArray()]);
            break;
        }
        Response::json(['error' => 'Method Not Allowed'], 405);
}
