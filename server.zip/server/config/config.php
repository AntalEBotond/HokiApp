<?php
// Basic configuration for database and app

return [
    'db' => [
        // XAMPP defaults
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        // MySQL port (XAMPP default 3306). Override via DB_PORT if needed.
        'port' => getenv('DB_PORT') ?: '3306',
        'name' => getenv('DB_NAME') ?: 'test',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
        'charset' => 'utf8mb4',
    ],
    // Token lifetime in seconds (e.g., 7 days)
    'auth' => [
        'token_ttl' => 7 * 24 * 60 * 60,
    ],
    // CORS for local development. Adjust for production.
    'cors' => [
        'allow_origin' => '*',
        'allow_headers' => 'Content-Type, Authorization',
        'allow_methods' => 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    ],
];
