-- MySQL / MariaDB schema for Flutter app backend

CREATE TABLE IF NOT EXISTS `user` (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username        VARCHAR(100) NOT NULL UNIQUE,
  email           VARCHAR(190) NULL UNIQUE,
  password_hash   VARCHAR(255) NOT NULL,
  full_name       VARCHAR(190) NULL,
  description     TEXT NULL,
  avatar_url      VARCHAR(255) NULL,
  banner_url      VARCHAR(255) NULL,
  avatar_mime     VARCHAR(64) NULL,
  avatar_blob     MEDIUMBLOB NULL,
  avatar_frame    VARCHAR(50) NULL,
  avatar_sticker  VARCHAR(16) NULL,
  status_note     VARCHAR(190) NULL,
  status_note_expires TIMESTAMP NULL DEFAULT NULL,
  status_note_color VARCHAR(10) NULL,
  status_note_bg VARCHAR(10) NULL,
  status_note_emoji VARCHAR(8) NULL,
  social_facebook VARCHAR(255) NULL,
  social_instagram VARCHAR(255) NULL,
  social_tiktok   VARCHAR(255) NULL,
  social_youtube  VARCHAR(255) NULL,
  -- Personalization / settings (2025)
  theme_mode      VARCHAR(12) NULL,           -- system | light | dark
  accent_color    VARCHAR(10) NULL,           -- #RRGGBB
  link_color      VARCHAR(10) NULL,
  language        VARCHAR(10) NULL,
  timezone        VARCHAR(64) NULL,
  pronouns        VARCHAR(32) NULL,
  website_url     VARCHAR(255) NULL,
  location        VARCHAR(190) NULL,
  birthdate       DATE NULL,
  birthdate_visibility VARCHAR(16) NULL,      -- hidden | friends | public
  text_scale      DECIMAL(3,2) NULL,          -- e.g. 1.00
  compact_mode    TINYINT(1) NOT NULL DEFAULT 0,
  reduce_motion   TINYINT(1) NOT NULL DEFAULT 0,
  halo_strength   DECIMAL(3,2) NULL,
  avatar_frame_favs TEXT NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_tokens (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  token_hash    CHAR(64) NOT NULL, -- sha256 hex
  issued_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  -- Make nullable to avoid invalid default errors in strict SQL modes
  expires_at    TIMESTAMP NULL DEFAULT NULL,
  INDEX (token_hash),
  INDEX (user_id),
  CONSTRAINT fk_tokens_user
    FOREIGN KEY (user_id) REFERENCES `user`(id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Simple posts table
CREATE TABLE IF NOT EXISTS posts (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  content    TEXT NOT NULL,
  image_url  VARCHAR(255) NULL,
  visibility VARCHAR(16) NOT NULL DEFAULT 'public',
  bg_color   VARCHAR(10) NULL,
  text_color VARCHAR(10) NULL,
  feeling_emoji VARCHAR(8) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id),
  CONSTRAINT fk_posts_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comments (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id    BIGINT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  parent_id  BIGINT UNSIGNED NULL,
  content    TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (post_id),
  INDEX (user_id),
  INDEX (parent_id),
  CONSTRAINT fk_comments_post FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_parent FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reactions (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id    BIGINT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  type       VARCHAR(20) NOT NULL DEFAULT 'like',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_user_post (post_id, user_id),
  INDEX (type),
  CONSTRAINT fk_reactions_post FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  CONSTRAINT fk_reactions_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reactions for comments (separate table)
CREATE TABLE IF NOT EXISTS comment_reactions (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comment_id   BIGINT UNSIGNED NOT NULL,
  user_id      INT UNSIGNED NOT NULL,
  type         VARCHAR(20) NOT NULL DEFAULT 'like',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_user_comment (comment_id, user_id),
  INDEX (type),
  CONSTRAINT fk_creact_comment FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE,
  CONSTRAINT fk_creact_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional seed admin (username: sysadm / password: sysadm)
-- NOTE: Do NOT use MySQL PASSWORD() here; PHP uses password_hash()/password_verify().
-- Either register via API or insert a row with a PHP-generated bcrypt/argon2 hash.
-- Example:
-- INSERT IGNORE INTO `user` (username, email, password_hash, full_name)
-- VALUES ('sysadm', NULL, '$2y$10$....bcrypt-hash....', 'Administrator');

-- Seed testing bot user (username: bot, password: bot)
-- Hash generated via: php -r "echo password_hash('bot', PASSWORD_DEFAULT);"
INSERT IGNORE INTO `user` (username, email, password_hash, full_name)
VALUES ('bot', NULL, '$2y$10$CNpJGoI602aYjNp0mr8sX.EBIdl4GMFBMighmIZ0JdIxOy.DUvIZ2', 'Test Bot');

-- ------------------------------------------------------------
-- Upgrades for existing installations (idempotent where supported)
-- Many local DBs already have an older 'posts' table without
-- visibility/bg_color/text_color/feeling_emoji columns. The below
-- ALTERs add them if missing. MariaDB and MySQL 8.0.29+ support
-- "ADD COLUMN IF NOT EXISTS". If your server doesn't, run the
-- individual ADD COLUMN statements manually.
-- ------------------------------------------------------------

-- Posts table upgrades
ALTER TABLE posts
  ADD COLUMN IF NOT EXISTS image_url VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS visibility VARCHAR(16) NOT NULL DEFAULT 'public',
  ADD COLUMN IF NOT EXISTS bg_color VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS text_color VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS feeling_emoji VARCHAR(8) NULL;

-- User table upgrades (profile and note related fields)
ALTER TABLE `user`
  ADD COLUMN IF NOT EXISTS avatar_url VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS banner_url VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS avatar_mime VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS avatar_blob MEDIUMBLOB NULL,
  ADD COLUMN IF NOT EXISTS avatar_frame VARCHAR(50) NULL,
  ADD COLUMN IF NOT EXISTS avatar_sticker VARCHAR(16) NULL,
  ADD COLUMN IF NOT EXISTS status_note VARCHAR(190) NULL,
  ADD COLUMN IF NOT EXISTS status_note_expires TIMESTAMP NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS status_note_color VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS status_note_bg VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS status_note_emoji VARCHAR(8) NULL,
  ADD COLUMN IF NOT EXISTS social_facebook VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS social_instagram VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS social_tiktok VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS social_youtube VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS theme_mode VARCHAR(12) NULL,
  ADD COLUMN IF NOT EXISTS accent_color VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS link_color VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS language VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS timezone VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS pronouns VARCHAR(32) NULL,
  ADD COLUMN IF NOT EXISTS website_url VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS location VARCHAR(190) NULL,
  ADD COLUMN IF NOT EXISTS birthdate DATE NULL,
  ADD COLUMN IF NOT EXISTS birthdate_visibility VARCHAR(16) NULL,
  ADD COLUMN IF NOT EXISTS text_scale DECIMAL(3,2) NULL,
  ADD COLUMN IF NOT EXISTS compact_mode TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS reduce_motion TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS halo_strength DECIMAL(3,2) NULL,
  ADD COLUMN IF NOT EXISTS avatar_frame_favs TEXT NULL;

-- Comments table upgrades
ALTER TABLE comments
  ADD COLUMN IF NOT EXISTS parent_id BIGINT UNSIGNED NULL,
  ADD INDEX IF NOT EXISTS parent_id (parent_id);

-- Comment reactions table (idempotent create)
CREATE TABLE IF NOT EXISTS comment_reactions (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comment_id   BIGINT UNSIGNED NOT NULL,
  user_id      INT UNSIGNED NOT NULL,
  type         VARCHAR(20) NOT NULL DEFAULT 'like',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_user_comment (comment_id, user_id),
  INDEX (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
