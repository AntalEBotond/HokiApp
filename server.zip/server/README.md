PHP OOP Backend for Flutter App

Overview
- Provides a small, object‑oriented PHP API for authentication and user profile management for this Flutter app.
- Uses PDO (MySQL/MariaDB) with prepared statements and password hashing.
- Endpoints return JSON and include permissive CORS headers for local development.

Structure
- `server/schema.sql` — Database schema (MySQL/MariaDB).
- `server/config/config.php` — DB credentials and basic config.
- `server/src/` — PHP classes (no Composer needed):
  - `Core/Database.php` — PDO wrapper
  - `Core/Response.php` — JSON/CORS helpers
  - `Models/User.php`
  - `Repositories/UserRepository.php`
  - `Repositories/TokenRepository.php`
  - `Services/AuthService.php`
  - `Services/ProfileService.php`
- `server/public/api/` — Endpoint scripts:
  - `login.php` — POST { username, password }
  - `register.php` — POST { username, password, full_name? }
  - `profile.php` — GET (read profile), POST (update profile), requires Bearer token
  - `avatar.php` — POST multipart upload (`file`) and DELETE to remove, requires Bearer token

Quick Start
1) Create database and tables
   - Create a database (e.g. `bot_app`).
   - Import `server/schema.sql` into your MySQL/MariaDB server.

2) Configure DB
   - Edit `server/config/config.php` and set DB host, name, user, pass.

3) Serve the API
   - Point your local PHP server (Apache/Nginx or `php -S`) to `server/public` as document root.
   - Example: `php -S 127.0.0.1:8088 -t server/public`

4) Test with curl
   - Register (optional):
     curl -X POST http://127.0.0.1:8088/api/register.php \
          -H "Content-Type: application/json" \
          -d '{"username":"sysadm","password":"sysadm","full_name":"Admin"}'

   - Login:
     curl -X POST http://127.0.0.1:8088/api/login.php \
          -H "Content-Type: application/json" \
          -d '{"username":"sysadm","password":"sysadm"}'

     Response includes `token` and `user`.

   - Get profile:
     curl http://127.0.0.1:8088/api/profile.php \
          -H "Authorization: Bearer <TOKEN_FROM_LOGIN>"

   - Update profile:
     curl -X POST http://127.0.0.1:8088/api/profile.php \
          -H "Authorization: Bearer <TOKEN_FROM_LOGIN>" \
          -H "Content-Type: application/json" \
          -d '{
                "full_name":"Nume Utilizator",
                "description":"Descriere",
                "social_facebook":"https://facebook.com/user",
                "social_instagram":"https://instagram.com/user",
                "social_tiktok":"https://tiktok.com/@user",
                "social_youtube":"https://youtube.com/@user"
              }'

   - Upload avatar:
     curl -X POST http://127.0.0.1:8088/api/avatar.php \
          -H "Authorization: Bearer <TOKEN_FROM_LOGIN>" \
          -F "file=@/full/path/to/avatar.jpg"

   - Remove avatar:
     curl -X DELETE http://127.0.0.1:8088/api/avatar.php \
          -H "Authorization: Bearer <TOKEN_FROM_LOGIN>"

Security Notes
- Passwords are hashed with `password_hash()` (bcrypt/argon). Never store plaintext.
- Login returns a random token. The API expects `Authorization: Bearer <token>`.
- Tokens are stored hashed (SHA‑256) in DB with expiration.

Next Steps / Optional
- Add `avatar.php` endpoint to upload avatar (multipart/form‑data) and store file path.
  (Implemented)
- Swap CORS to allowlist in production and enforce HTTPS.
- Add rate limiting and audit logs for sensitive endpoints.
