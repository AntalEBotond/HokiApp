<?php
namespace App\Models;

class Post
{
    public int $id;
    public int $userId;
    public string $content;
    public ?string $imageUrl;
    public string $visibility = 'public';
    public ?string $bgColor = null;
    public ?string $textColor = null;
    public ?string $feelingEmoji = null;
    public string $createdAt;

    // Joined user info
    public ?string $userName = null;
    public ?string $userAvatar = null;

    public static function fromArray(array $row): self
    {
        $p = new self();
        $p->id = (int)($row['id'] ?? 0);
        $p->userId = (int)($row['user_id'] ?? 0);
        $p->content = (string)($row['content'] ?? '');
        $p->imageUrl = $row['image_url'] ?? null;
        $p->visibility = (string)($row['visibility'] ?? 'public');
        $p->bgColor = $row['bg_color'] ?? null;
        $p->textColor = $row['text_color'] ?? null;
        $p->feelingEmoji = $row['feeling_emoji'] ?? null;
        $p->createdAt = (string)($row['created_at'] ?? '');
        $p->userName = $row['user_name'] ?? null;
        $p->userAvatar = $row['user_avatar'] ?? null;
        return $p;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->userId,
            'content' => $this->content,
            'image_url' => $this->imageUrl,
            'visibility' => $this->visibility,
            'bg_color' => $this->bgColor,
            'text_color' => $this->textColor,
            'feeling_emoji' => $this->feelingEmoji,
            'created_at' => $this->createdAt,
            'user_name' => $this->userName,
            'user_avatar' => $this->userAvatar,
        ];
    }
}
