<?php
namespace App\Models;

class User
{
    public int $id;
    public string $username;
    public ?string $email;
    public string $passwordHash;
    public ?string $fullName;
    public ?string $description;
    public ?string $avatarUrl;
    public ?string $bannerUrl;
    public ?string $avatarFrame;
    public ?string $avatarSticker;
    public ?string $statusNote;
    public $statusNoteExpires; // string|null (TIMESTAMP)
    public ?string $statusNoteColor;
    public ?string $statusNoteBg;
    public ?string $statusNoteEmoji;
    public ?string $socialFacebook;
    public ?string $socialInstagram;
    public ?string $socialTiktok;
    public ?string $socialYoutube;
    // Personalization / settings
    public ?string $themeMode;
    public ?string $accentColor;
    public ?string $linkColor;
    public ?string $language;
    public ?string $timezone;
    public ?string $pronouns;
    public ?string $websiteUrl;
    public ?string $location;
    public $birthdate; // string|null (DATE)
    public ?string $birthdateVisibility;
    public $textScale; // string|float|null
    public int $compactMode = 0;
    public int $reduceMotion = 0;
    public $haloStrength; // string|float|null
    public ?string $avatarFrameFavs = null;

    public static function fromArray(array $row): self
    {
        $u = new self();
        $u->id = (int)($row['id'] ?? 0);
        $u->username = (string)($row['username'] ?? '');
        $u->email = $row['email'] ?? null;
        $u->passwordHash = (string)($row['password_hash'] ?? '');
        $u->fullName = $row['full_name'] ?? null;
        $u->description = $row['description'] ?? null;
        $u->avatarUrl = $row['avatar_url'] ?? null;
        $u->bannerUrl = $row['banner_url'] ?? null;
        $u->avatarFrame = $row['avatar_frame'] ?? null;
        $u->avatarSticker = $row['avatar_sticker'] ?? null;
        $u->statusNote = $row['status_note'] ?? null;
        $u->statusNoteExpires = $row['status_note_expires'] ?? null;
        $u->statusNoteColor = $row['status_note_color'] ?? null;
        $u->statusNoteBg = $row['status_note_bg'] ?? null;
        $u->statusNoteEmoji = $row['status_note_emoji'] ?? null;
        $u->socialFacebook = $row['social_facebook'] ?? null;
        $u->socialInstagram = $row['social_instagram'] ?? null;
        $u->socialTiktok = $row['social_tiktok'] ?? null;
        $u->socialYoutube = $row['social_youtube'] ?? null;
        $u->themeMode = $row['theme_mode'] ?? null;
        $u->accentColor = $row['accent_color'] ?? null;
        $u->linkColor = $row['link_color'] ?? null;
        $u->language = $row['language'] ?? null;
        $u->timezone = $row['timezone'] ?? null;
        $u->pronouns = $row['pronouns'] ?? null;
        $u->websiteUrl = $row['website_url'] ?? null;
        $u->location = $row['location'] ?? null;
        $u->birthdate = $row['birthdate'] ?? null;
        $u->birthdateVisibility = $row['birthdate_visibility'] ?? null;
        $u->textScale = $row['text_scale'] ?? null;
        $u->compactMode = (int)($row['compact_mode'] ?? 0);
        $u->reduceMotion = (int)($row['reduce_motion'] ?? 0);
        $u->haloStrength = $row['halo_strength'] ?? null;
        $u->avatarFrameFavs = $row['avatar_frame_favs'] ?? null;
        return $u;
    }

    public function toPublicArray(): array
    {
        return [
            'id' => $this->id,
            'username' => $this->username,
            'full_name' => $this->fullName,
            'description' => $this->description,
            'avatar_url' => $this->avatarUrl,
            'banner_url' => $this->bannerUrl,
            'avatar_frame' => $this->avatarFrame,
            'avatar_sticker' => $this->avatarSticker,
            'status_note' => $this->statusNote,
            'status_note_expires' => $this->statusNoteExpires,
            'status_note_color' => $this->statusNoteColor,
            'status_note_bg' => $this->statusNoteBg,
            'status_note_emoji' => $this->statusNoteEmoji,
            'social_facebook' => $this->socialFacebook,
            'social_instagram' => $this->socialInstagram,
            'social_tiktok' => $this->socialTiktok,
            'social_youtube' => $this->socialYoutube,
            'theme_mode' => $this->themeMode,
            'accent_color' => $this->accentColor,
            'link_color' => $this->linkColor,
            'language' => $this->language,
            'timezone' => $this->timezone,
            'pronouns' => $this->pronouns,
            'website_url' => $this->websiteUrl,
            'location' => $this->location,
            'birthdate' => $this->birthdate,
            'birthdate_visibility' => $this->birthdateVisibility,
            'text_scale' => $this->textScale,
            'compact_mode' => (bool)$this->compactMode,
            'reduce_motion' => (bool)$this->reduceMotion,
            'halo_strength' => $this->haloStrength,
            'avatar_frame_favs' => $this->avatarFrameFavs,
        ];
    }
}
