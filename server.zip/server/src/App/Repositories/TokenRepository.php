<?php
namespace App\Repositories;

use App\Core\Database;
use PDO;

class TokenRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::pdo();
    }

    public function create(int $userId, string $rawToken, int $ttlSeconds): string
    {
        $tokenHash = hash('sha256', $rawToken);
        $stmt = $this->pdo->prepare('INSERT INTO user_tokens (user_id, token_hash, issued_at, expires_at) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? SECOND))');
        $stmt->execute([$userId, $tokenHash, $ttlSeconds]);
        return $rawToken;
    }

    public function findUserIdByToken(string $rawToken): ?int
    {
        $tokenHash = hash('sha256', $rawToken);
        $stmt = $this->pdo->prepare('SELECT user_id FROM user_tokens WHERE token_hash = ? AND expires_at > NOW() LIMIT 1');
        $stmt->execute([$tokenHash]);
        $row = $stmt->fetch();
        return $row ? (int)$row['user_id'] : null;
    }

    public function revoke(string $rawToken): void
    {
        $tokenHash = hash('sha256', $rawToken);
        $stmt = $this->pdo->prepare('DELETE FROM user_tokens WHERE token_hash = ?');
        $stmt->execute([$tokenHash]);
    }
}

