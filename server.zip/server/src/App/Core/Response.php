<?php
namespace App\Core;

class Response
{
    public static function json($data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    public static function cors(array $config): void
    {
        $cors = $config['cors'] ?? [];
        header('Access-Control-Allow-Origin: ' . ($cors['allow_origin'] ?? '*'));
        header('Access-Control-Allow-Headers: ' . ($cors['allow_headers'] ?? 'Content-Type, Authorization'));
        header('Access-Control-Allow-Methods: ' . ($cors['allow_methods'] ?? 'GET, POST, PUT, PATCH, DELETE, OPTIONS'));
    }
}

