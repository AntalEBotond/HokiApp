library menu_screen;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '/models/menu_item_data.dart';
import '/profil/framed_avatar.dart';
import '/profil/profile_page.dart';
import '/services/api_service.dart';
import '/utils/i18n.dart';
import '/widgets/left_side_menu.dart';
import '/widgets/settings_screen.dart';
import '/widgets/skeleton_post.dart';

part 'menu/feed_section.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> with _FeedSection {
  int _selectedIndex = 0;
  bool _collapsed = false;

  @override
  void initState() {
    super.initState();
    initFeed();
  }

  @override
  void dispose() {
    disposeFeed();
    super.dispose();
  }

  List<MenuItemData> _items(BuildContext context) => [
        MenuItemData(icon: Icons.home_outlined, title: I18n.t(context, 'home')),
        MenuItemData(icon: Icons.person_outline, title: I18n.t(context, 'profile')),
        MenuItemData(icon: Icons.settings_outlined, title: I18n.t(context, 'settings')),
        MenuItemData(icon: Icons.help_outline, title: I18n.t(context, 'help')),
        MenuItemData(icon: Icons.logout, title: 'Logout'),
      ];

  Future<void> _logout(BuildContext context) async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove('auth_token');
    if (!mounted) return;
    Navigator.of(context).pushReplacementNamed('/login');
  }

  Widget _helpPlaceholder(ThemeData theme) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Text(
          I18n.t(context, 'help_placeholder'),
          style: theme.textTheme.bodyLarge,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final titles = [
      I18n.t(context, 'home'),
      I18n.t(context, 'profile'),
      I18n.t(context, 'settings'),
      I18n.t(context, 'help'),
    ];
    final width = MediaQuery.of(context).size.width;
    final isCompact = width < 720;
    final menuItems = _items(context);
    final logoutIndex = menuItems.length - 1;

    Widget pageFor(int index) {
      switch (index) {
        case 0:
          return _buildFeed(context, theme);
        case 1:
          return const ProfilePage();
        case 2:
          return const SettingsScreen();
        default:
          return _helpPlaceholder(theme);
      }
    }

    final content = AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      child: pageFor(_selectedIndex.clamp(0, titles.length - 1)),
    );

    if (isCompact) {
      return Scaffold(
        appBar: AppBar(
          title: Text(titles[_selectedIndex.clamp(0, titles.length - 1)]),
          actions: _selectedIndex == 0 ? buildHomeActions(context) : null,
        ),
        drawer: Drawer(
          child: LeftSideMenu(
            items: menuItems,
            selectedIndex: _selectedIndex,
            onItemSelected: (i) {
              Navigator.of(context).pop();
              if (i == logoutIndex) {
                _logout(context);
                return;
              }
              setState(() => _selectedIndex = i.clamp(0, titles.length - 1));
            },
            collapsed: false,
          ),
        ),
        body: content,
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(titles[_selectedIndex.clamp(0, titles.length - 1)]),
        actions: _selectedIndex == 0 ? buildHomeActions(context) : null,
      ),
      body: Row(
        children: [
          LeftSideMenu(
            items: menuItems,
            selectedIndex: _selectedIndex,
            collapsed: _collapsed,
            onCollapseToggle: (value) => setState(() => _collapsed = value),
            onItemSelected: (i) {
              if (i == logoutIndex) {
                _logout(context);
                return;
              }
              setState(() => _selectedIndex = i.clamp(0, titles.length - 1));
            },
          ),
          Expanded(child: content),
        ],
      ),
    );
  }
}
