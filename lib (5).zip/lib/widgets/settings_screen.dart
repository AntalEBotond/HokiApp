import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/settings_service.dart';
import '../utils/i18n.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = SettingsController.instance;
    return AnimatedBuilder(
      animation: s,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(I18n.t(context, 'settings'), style: Theme.of(context).textTheme.heaadlineSmall),
            const SizedBox(height: 12),
            _card(
              context,
              title: I18n.t(context, 'theme'),
              child: Column(
                children: [
                  RadioListTile<ThemeMode>(
                    value: ThemeMode.system,
                    groupValue: s.themeMode,
                    onChanged: (v) => s.setThemeMode(v ?? ThemeMode.system),
                    title: Text(I18n.t(context, 'system')),
                  ),
                  RadioListTile<ThemeMode>(
                    value: ThemeMode.light,
                    groupValue: s.themeMode,
                    onChanged: (v) => s.setThemeMode(v ?? ThemeMode.light),
                    title: Text(I18n.t(context, 'light')),
                  ),
                  RadioListTile<ThemeMode>(
                    value: ThemeMode.dark,
                    groupValue: s.themeMode,
                    onChanged: (v) => s.setThemeMode(v ?? ThemeMode.dark),
                    title: Text(I18n.t(context, 'dark')),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),
            _card(
              context,
              title: I18n.t(context, 'language'),
              child: Row(
                children: [
                  DropdownButton<Locale?>(
                    value: s.locale,
                    items: const [
                      DropdownMenuItem(value: null, child: Text('System')),
                      DropdownMenuItem(value: Locale('hu'), child: Text('Magyar')),
                      DropdownMenuItem(value: Locale('en'), child: Text('English')),
                      DropdownMenuItem(value: Locale('ro'), child: Text('Romana')),
                    ],
                    onChanged: (v) => s.setLocale(v),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _card(BuildContext context, {required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

extension on TextTheme {
  TextStyle? get heaadlineSmall => null;
}

